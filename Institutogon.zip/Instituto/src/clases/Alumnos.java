/*
 * @author Gonzalo
 * @version 0.0.1
 * 
 */
package clases;


public class Alumnos {
	private String nombre;
	private int edad;
	private int nModulos;
	private Notas notas;
	
	/*
	 * 
	 * @param Nombre del alumno
	 * @param Edad del alumno
	 * @param N�mero de m�dulos del alumno
	 * @param Las notas de cada m�dulo del alumno
	 */
	//constructor
	public Alumnos(String nombre, int edad, int nModulos, Notas notas) {
		this.nombre=nombre;
		if (edad > 0) {
			this.edad = edad;
		}else {
			throw new IllegalArgumentException ("Edad de "+nombre+" incorrecta");
			}
		if (nModulos > 0 && nModulos <= 3) {
			this.nModulos = nModulos;
		}else {
			throw new IllegalArgumentException ("N�mero de m�dulos m�ximos: 3");
		}
		
		this.notas=notas;
	}

	/*
	 * @return de nombre (obtener)
	 */

	public String getNombre() {
		return nombre;
	}
	
	/*
	 * @return de nombre set
	 */
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/*
	 * @return de edad (obtener)
	 */
	public int getEdad() {
		return edad;
	}
	/*
	 * @return de edad set
	 */
	public void setEdad(int edad) {
		if (edad > 0) {
			this.edad = edad;
		}else {
			throw new IllegalArgumentException ("Edad de "+nombre+" incorrecta");
		}
	
	}
	
	/*
	 * @return the nModulos (obtener)
	 */
	public int getnModulos() {
		return nModulos;
	}

	/*
	 * @param nModulos the nModulos set
	 */
	public void setnModulos(int nModulos) {
		if (nModulos > 0 && nModulos <= 3) {
			this.nModulos = nModulos;
		}else {
			throw new IllegalArgumentException ("N�mero de m�dulos m�ximos: 3");
		}
	}
	
	/*
	 * @return nota (obtener)
	 */
	public Notas getNotas() {
		return notas;
	}

	public void setNotas(Notas notas) {
		this.notas = notas;
	}
	
	@Override
	public String toString() {
		return nombre + " tiene " + edad + " a�os y est� matriculado en " + nModulos + " m�dulos, sus notas son: " + notas;
	}

	

}
