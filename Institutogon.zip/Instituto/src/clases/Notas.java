/*
 * @author Gonzalo
 * @version 0.0.1
 * 
 */
package clases;
import java.util.ArrayList;
import java.util.List;

public class Notas {
private List <Integer> notas = new ArrayList<Integer>();
	
	/*
	 * 
	 * @param Listado de notas del alumno
	 */
	//constructor notas
	public Notas(int n) {
		if (n >= 0 && n<=10 ) {
			notas.add(n);
		}else {
			throw new IllegalArgumentException ("Las notas deben est�r comprendidas entre 0 y 10");
		}
	}
	
	public Notas(int n, int n2) {
		if (n >= 0 && n<=10 && n2 >= 0 && n2<=10) {
			notas.add(n);
			notas.add(n2);
		}else {
			throw new IllegalArgumentException ("Las notas deben est�r comprendidas entre 0 y 10");
		}
	}
	
	public Notas(int n, int n2, int n3) {
		if (n >= 0 && n <= 10 && n2 >= 0 && n2<=10 && n3 >= 0 && n3 <= 10) {
			notas.add(n);
			notas.add(n2);
			notas.add(n3);
		}else {
			throw new IllegalArgumentException ("Las notas deben est�r comprendidas entre 0 y 10");
		}
	}

	/*
	 * @return the notas (obtener)
	 */
	public List<Integer> getNotas() {
		return notas;
	}

	/*
	 * @param notas the notas set
	 */
	public void setNotas(List<Integer> notas) {
		this.notas = notas;
	}
	
	
	@Override
	public String toString() {
		return notas.toString();
	}
	

}
