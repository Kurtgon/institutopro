package main;
/*
 * @author Gonzalo
 * @version 0.0.1
 * 
 */

import java.util.Scanner;

import clases.Alumnos;
import clases.Lista;
import clases.Notas;



public class Main {
	public static void main (String[]args) {
		Scanner ms = new Scanner(System.in);
		Scanner my = new Scanner(System.in);
		Lista lis = new Lista();
		
		//crear alumnos
		try {
		lis.nuevoAlumno(new Alumnos("Gonzalo",30, 7, new Notas(8)));
		lis.nuevoAlumno(new Alumnos("Robert",21, 9, new Notas(10)));
		lis.nuevoAlumno(new Alumnos("Samu",25, 7, new Notas (6)));
		lis.nuevoAlumno(new Alumnos("Raul",23, 7, new Notas (8)));
		}catch (IllegalArgumentException errores) {
			System.out.println(errores);
		}
	
	
		//Men�
		System.out.println(lis.tamano()+" ");
		System.out.println("Alumnos");
		System.out.println("---------------");
		lis.listado();
		System.out.println("");
		System.out.println("�Qu� deseas hacer? \n1. Editar notas \n2. Hacer media de los alumnos y ver cuantos son. \n3. Ver lista alumnos ordenada \nPara salir introduce otro n�mero." );
		int opcion = ms.nextInt();
				
		switch (opcion) {
		case 1:
					
			boolean salir = false;
			String nombre = "";
			do {
				System.out.println("Introduce el nombre del alumno al que quieras modificar las notas.");
				nombre = my.nextLine();
			
				int posicion = lis.buscarAlumno(nombre);
						
				if (posicion >= 0) {
					System.out.println("Alumno "+nombre +" est� en la posici�n "+ posicion);
					lis.cambiaNotas(posicion);
					lis.listado();
					salir = true;
				}else if (nombre.equals("fin")) {
					System.out.println("Adios.");
				}else {
					System.out.println("Nombre no encontrado");
				}
			}while ( salir == false && !nombre.equals("fin"));
			break;
				//sin hacer	
		case 2: 
			break;
				
		case 3:
			lis.listadoOrdenado();
			break;
					
		default:
			break;

		}
		my.close();
		ms.close();
	}
}
	
		

